<?php foreach ($d->movements as $mov): ?>
    <b><?php echo $mov->selecion;?></b>
<?php endforeach; ?>
      